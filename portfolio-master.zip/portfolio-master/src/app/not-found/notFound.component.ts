import { Component } from "@angular/core";

@Component({
    templateUrl: "./notFound.component.html"
})

export class notfoundComponent{

}
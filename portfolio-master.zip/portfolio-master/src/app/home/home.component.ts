import { Component } from "@angular/core";

@Component({
    selector: "home",
    templateUrl: "./index.component.html",
})

export class homeComponent {
}
import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
    template: `<portfolio-header></portfolio-header>`,
})
export class AppComponent  { }

﻿import { Component } from "@angular/core";

@Component({
    selector: "portfolio-header",
    templateUrl: "./header.component.html",
    styleUrls:["app/css/header.css"],
})

export class headerComponent {
    mylogo: string = ".SRC.";
}
import { Component } from "@angular/core";

@Component({
    selector:"work",
    templateUrl:"./portfolio.component.html",    
})

export class portfolioComponent{

}
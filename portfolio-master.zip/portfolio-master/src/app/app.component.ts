import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  templateUrl: './appComponent.html',
  styleUrls: ["app/css/header.css"],
})
export class AppComponent {
  mylogo: string = ".SRC.";
  home: string = "Home";
  portfolio: string = "Portfolio";
  services: string = "Services"
  contact: string = "Contact"
}

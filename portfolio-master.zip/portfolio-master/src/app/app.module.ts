import { NgModule } from "@angular/core" ;
import { BrowserModule } from "@angular/platform-browser" ;
import { RouterModule, Routes } from "@angular/router";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";

import { AppComponent } from './app.component';
import { homeComponent } from './home/home.component';
import { portfolioComponent } from './portfolio/portfolio.component';
import { DialogComponent } from './dialog/dialog.component';
import { notfoundComponent } from './not-found/notFound.component';

const appRoutes: Routes = [
  { path: 'portfolio', component: portfolioComponent },
  { path: 'home', component: homeComponent },
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: '**', component: notfoundComponent }
];

@NgModule({
  imports:      [ BrowserModule, RouterModule.forRoot(appRoutes), BrowserAnimationsModule ],
  
  declarations: [ AppComponent, homeComponent, portfolioComponent, notfoundComponent, DialogComponent ],
  bootstrap:    [ AppComponent ]
})

export class AppModule { }
